<div class="user-panel">
    <div class="image pull-left">
        <a href=""><img src="../base/img/rocket.jpg" class="img-circle" alt="User Image"></a>
    </div>
    <div class="slogan pull-right">
        <h3 class="pull-left">Arduino</h3>
        <br>
        <h5 class="pull-left">Monitoring Systems</h5>
    </div>
</div>