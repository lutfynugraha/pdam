<?php include_once '../base/includes/header.php'; ?>
<!-- navbar -->
<?php include_once '../base/includes/navbar.php'; ?>
<!-- Sidebar -->    
<?php include_once '../base/includes/sidebar.php'; ?>
<!-- /#sidebar-wrapper -->

<?php include_once 'includes/form_profile.php'; ?>

<?php include_once '../base/includes/footer.php'; ?>

