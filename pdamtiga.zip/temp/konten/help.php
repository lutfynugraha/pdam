<!-- Page Content -->
    <body style="background: url(img/background2.jpg);background-position: center; background-repeat: no-repeat;background-size: cover;">
        <div class="container" style="margin-top: 50px;">
            <form class="form-signin" action="" method="post" style="height: 400px">
            <div style="margin-left:50px;"><img src="img/logo.png" style="width: 200px"></div>
                <h3  align="center"><span style="font-size: 17px; color: #000">PDAM Tirta Kamuning Cab.Pasapen</span></h3>
<div id="page-content-wrapper">
    <div class="container-fluid">  

        <hr class="style-four">
        <div class="row">
            <div class="col-lg-12">
                <section class="content-header"><center><h3>Visi</h3></center></section>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <ol type="1">
                    <li>Menjadikan PDAM yang sehat dan mampu memberikan pelayanan yang prima <br />
                    Sistem ini dibuat oleh : LUTFY NUGRAHA</li>
                </ol>
            </div>
        </div>

        <hr class="style-four">
        <div class="row">
            <div class="col-lg-12">
                <section class="content-header"><center><h3>Misi</h3></center></section>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <ol type="1">
                    <li>Memberikan pelayanan Air minum kepada masyarakat yang memenuhi K-3 (Kualitas, Kuantitas, Kontinuitas) dan Terjangkau.</li>
                    <li>Memberi kontribusi kepada pembangunan daerah.</li>
                    <li>Menunjang Pemerintah Daerah dalam Usaha Meningkatkan Derajat Kesehatan Masyarakat dan Pelestarian Lingkungan.</li>
                </ol>
            </div>
        </div>

        <hr class="style-four">
        <div class="row">
            <div class="col-lg-12">
                <section class="content-header"><center><h3>Moto</h3></center></section>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <center><b>MENGUTAMAKAN PELAYANAN DAN KEPUASAN PELANGGAN</b></center> 
            </div>
        </div>

    </div>
</form>
</div>
</body>