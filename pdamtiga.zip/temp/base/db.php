<?php
define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASS','');
define('DATABASE','pdam3');
error_reporting(0);
$con = mysqli_connect(DB_HOST,DB_USER,DB_PASS,DATABASE);

?>