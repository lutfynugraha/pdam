<!-- Page Content -->
<div id="page-content-wrapper">
    <div class="container-fluid">  

        <hr class="style-four">
        <div class="row">
            <div class="col-lg-12">
                <section class="content-header"><center><h3>Visi</h3></center></section>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <ol type="1">
                    <li>Menjadikan PDAM yang sehat dan mampu memberikan pelayanan yang prima <br />
                    Sistem ini dibuat oleh : LUTFY NUGRAHA</li>
                </ol>
            </div>
        </div>

        <hr class="style-four">
        <div class="row">
            <div class="col-lg-12">
                <section class="content-header"><center><h3>Misi</h3></center></section>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <ol type="1">
                    <li>Memberikan pelayanan Air minum kepada masyarakat yang memenuhi K-3 (Kualitas, Kuantitas, Kontinuitas) dan Terjangkau.</li>
                    <li>Memberi kontribusi kepada pembangunan daerah.</li>
                    <li>Menunjang Pemerintah Daerah dalam Usaha Meningkatkan Derajat Kesehatan Masyarakat dan Pelestarian Lingkungan.</li>
                </ol>
            </div>
        </div>

        <hr class="style-four">
        <div class="row">
            <div class="col-lg-12">
                <section class="content-header"><center><h3>Moto</h3></center></section>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <center><b>MENGUTAMAKAN PELAYANAN DAN KEPUASAN PELANGGAN</b></center> 
            </div>
        </div>
                <hr class="style-four">  
        <div class="row">
            <div class="col-xs-12">
                <center><b>Lutfy Nugraha</b></center> <br>
                <center><b>Fakultas Ilmu Komputer</b></center> <br>
                <center><b>Universitas Kuningan</b></center> 
            </div>
        </div>

    </div>