                    <div class="spacer"></div>
                    <hr class="style-four">
                    <div class="spacer"></div>
                    <footer class="footer">    
                          <p class="text-muted pull-left"><b>&copy ĐỒ ÁN TỐT NGHIỆP 2016 </b> Arduino Monitoring System </p>
                          <p class="text-muted pull-right">Created by <b>Dân Tộc Xuống Phố</b></p>
                    </footer>
                </div>
            </div>
            <!-- /#page-content-wrapper -->
        </div>
        <!-- /#wrapper -->
        

        <!-- Bootstrap Core JavaScript -->
        <script src="../base/js/bootstrap.min.js"></script>
        

    
        <!-- GUAGE SECTION -->
        <script src="../base/js/guage/raphael-2.1.4.min.js"></script>
        <script src="../base/js/guage/justgage-1.1.0.min.js"></script>
        <!-- Menu Toggle Script -->
        <script src="https://cdn.datatables.net/1.10.10/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.10.10/js/dataTables.bootstrap.min.js"></script>
        
        
        
        
        <!-- Slider -->
        <script src="../base/js/slider/freshslider.min.js"></script>
        <script>
            $("#menu-toggle").click(function(e) {
                  e.preventDefault();
                  $("#wrapper").toggleClass("toggled");
            });
            


        </script>
    </body>
</html>